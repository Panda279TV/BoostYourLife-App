-- phpMyAdmin SQL Dump
-- version 4.9.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Erstellungszeit: 14. Feb 2020 um 19:42
-- Server-Version: 5.7.26
-- PHP-Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `Boost-Your-Life`
--
CREATE DATABASE IF NOT EXISTS `Boost-Your-Life` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `Boost-Your-Life`;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `images`
--
-- Erstellt am: 14. Feb 2020 um 15:28
-- Zuletzt aktualisiert: 14. Feb 2020 um 19:34
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `nlpid` int(11) DEFAULT NULL,
  `tablename` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  `size` int(10) NOT NULL,
  `src` varchar(125) NOT NULL,
  `uploaded` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `images`
--

INSERT INTO `images` (`id`, `userid`, `nlpid`, `tablename`, `name`, `type`, `size`, `src`, `uploaded`) VALUES
(1, 1, 1, 'Nlp', 'NLP-Verstärken-Sie-Ihre-Wahrnehmung', 'png', 37505, 'db-images/NLP-Verstärken-Sie-Ihre-Wahrnehmung.png', '2020-02-01 17:01:28'),
(2, 1, 2, 'Nlp', 'NLP-NLP-Und-Kongruenz', 'png', 24605, 'db-images/NLP-NLP-Und-Kongruenz.png', '2020-02-02 17:20:34'),
(3, 1, 3, 'Nlp', 'NLP-Wie-Repräsentieren-Sie-Ihre-Welt', 'png', 41182, 'db-images/NLP-Wie-Repräsentieren-Sie-Ihre-Welt.png', '2020-02-03 17:41:56'),
(4, 2, 4, 'Nlp', 'NLP-Kalibrieren', 'png', 17396, 'db-images/NLP-Kalibrieren.png', '2020-02-04 17:53:09'),
(5, 2, 5, 'Nlp', 'NLP-Rapport-Pacing-und-Leading', 'png', 35714, 'db-images/NLP-Rapport-Pacing-und-Leading.png', '2020-02-05 18:07:11'),
(6, 4, 6, 'Nlp', 'NLP-Überkreuz-Spiegeln', 'png', 27298, 'db-images/NLP-Überkreuz-Spiegeln.png', '2020-02-06 18:14:57'),
(7, 1, NULL, 'Profile', 'Benedikt-Wolf-2019', 'jpg', 7258644, 'db-images/Benedikt-Wolf-2019.jpg', '2020-02-10 18:24:17'),
(8, 5, 7, 'Nlp', 'NLP-Klassisches-Anker-Verschmelzen', 'png', 35609, 'db-images/NLP-Klassisches-Anker-Verschmelzen.png', '2020-02-14 18:53:54'),
(9, 5, 8, 'Nlp', 'NLP-Die-Swish-Technik', 'png', 26358, 'db-images/NLP-Die-Swish-Technik.png', '2020-02-14 19:02:36'),
(10, 5, 9, 'Nlp', 'NLP-Walt-Disney-Strategie', 'png', 31989, 'db-images/NLP-Walt-Disney-Strategie.png', '2020-02-14 19:14:01'),
(11, 5, 10, 'Nlp', 'NLP-Six-Step-Reframing', 'png', 29539, 'db-images/NLP-Six-Step-Reframing.png', '2020-02-14 19:24:57'),
(12, 3, NULL, 'Profile', 'adult-1850703_1920', 'jpg', 403935, 'db-images/adult-1850703_1920.jpg', '2020-02-14 19:28:45'),
(13, 2, NULL, 'Profile', 'man-1246508_1920', 'jpg', 771499, 'db-images/man-1246508_1920.jpg', '2020-02-14 19:29:53'),
(14, 5, NULL, 'Profile', 'dog-3739225_1920', 'jpg', 456653, 'db-images/dog-3739225_1920.jpg', '2020-02-14 19:33:48'),
(15, 4, NULL, 'Profile', 'small-poly-3310319_1920', 'jpg', 190753, 'db-images/small-poly-3310319_1920.jpg', '2020-02-14 19:34:53');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `nlp`
--
-- Erstellt am: 14. Feb 2020 um 16:50
-- Zuletzt aktualisiert: 14. Feb 2020 um 19:25
--

DROP TABLE IF EXISTS `nlp`;
CREATE TABLE `nlp` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `author` varchar(75) NOT NULL,
  `title` varchar(45) NOT NULL,
  `description` varchar(200) NOT NULL,
  `text` text NOT NULL,
  `genre` varchar(20) NOT NULL,
  `soundcloud` varchar(255) DEFAULT NULL,
  `youtube` varchar(255) DEFAULT NULL,
  `uploaded` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `unlocked` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `nlp`
--

INSERT INTO `nlp` (`id`, `userid`, `author`, `title`, `description`, `text`, `genre`, `soundcloud`, `youtube`, `uploaded`, `unlocked`) VALUES
(1, 1, 'Benedikt Wolf', 'Verstärken Sie Ihre Wahrnehmung', 'Wir Menschen nehmen die Welt mit unseren 5 Sinnen wahr. Umso mehr Sie wahrnehmen, desto größer ist die Wahrscheinlichkeit, Ihr Gegenüber besser einschätzen zu können.', 'a) Durch die Welt gehen ohne Bewertung. Gehen Sie morgen früh mal mit allen Sinnen aus dem Haus. Achten Sie dabei nicht nur darauf, das evtl. vor Ihrem Haus eine Pflanze steht, sondern auf jede Kleinigkeit, die Farbe, die Formen usw. und vielleicht streicht gerade der Wind über die Pflanze und sie hören genau hin, welche Töne sie wahrnehmen. Je mehr Sinne sie einbeziehen um so besser. b) Wenn Sie sich heute mit Menschen unterhalten, achten Sie auf etwas anderes, auf das Sie sich sonst nicht konzentrieren. Vielleicht achten Sie auf die Beinstellung, den Abstand, ob die Knie leicht angewinkelt sind usw. Ob Sie die Ohren der Person sehen können? Achten Sie darauf, ob die Person einen Ring trägt.', 'A', NULL, NULL, '2020-02-01 17:01:28', 1),
(2, 1, 'Benedikt Wolf', 'NLP und Kongruenz', 'Kongruenz, bedeutet allgemein Übereinstimmung. Im Bereich der Psychotherapie beschreibt Kongruenz die authentische Kommunikation eines Menschen.', 'a) Beim nächsten Gespräch achten Sie auf die Kongruenz (Übereinstimmung) von Worten und Tonfall. Meint Ihr Gegenüber das, was er sagt, oder haben Sie einen anderen Eindruck? b) Wie sieht es mit Ihrer eigenen Kongruenz aus? Verstellen Sie sich, wenn sie mit jemandem sprechen? Vielleicht achten Sie einen Tag lang besonders darauf, dass Ihr Körper die Wirkung Ihrer Worte unterstreicht. c) Probieren Sie doch einmal selbst aus, dass Sie etwas sagen und der Körper sagt etwas anderes. Oder Sie unterstreichen und verstärken mit Ihrer Körpersprache das, was Sie sagen.', 'G', NULL, NULL, '2020-02-02 17:20:34', 1),
(3, 1, 'Benedikt Wolf', 'Wie repräsentieren Sie Ihre Welt in Ihnen', 'Bei der letzten Übung haben Sie Ihre Wahrnehmung auf alles gerichtet, was um Sie herum ist. Heute geht es darum, wie Sie etwas Wahrgenommenes in Ihrer Innenwelt repräsentieren.', 'a) Es kann sein, dass die folgende Übung für manche Menschen eine kleine Herausforderung darstellt. Keine Sorge, mit etwas üben wird es ihnen immer leichter fallen. Egal, wo Sie jetzt sind, konzentrieren Sie sich auf ein Ding, was Sie gerade vor sich sehen. Dann schließen Sie die Augen und stellen Sie sich nun den Gegenstand vor Ihrem geistigen Auge vor. Wenn das nicht so ganz geklappt hat. Noch mal Augen auf. Auf den Gegenstand konzentrieren und Ihr inneres Bild noch genauer werden lassen. Ein Freund hat mir mal erzählt, dass er in den ersten 3 Wochen überhaupt nichts gesehen hätte außer Schwarzer Bildschirm. Und sein Trick war dann, sich erst ein Streichholz anzuzünden (natürlich nur im Geiste), damit er überhaupt an seine Bilder im inneren kam. b) Sicherlich haben Sie schon Ihre Stimme auf einem Video oder Tonband gehört. Wir können uns nicht selbst zuhören, wenn wir sprechen. Nehmen Sie ein Gespräch von sich selbst auf und nehmen wahr, was andere Menschen in Ihrer Nähe den ganzen Tag so hören. Lautstärke, Pausen, Tempo, Rhythmus und Tonfall c) Wie riecht Ihre Lieblingsmarmelade? Wie riechen verschiedene Kräuter in Ihrem Garten? Können Sie diese Informationen nur in Ihrem Geiste abrufen. d) Berühren Sie Ihren Partner oder einen Freund. Schließen Sie danach die Augen und versuchen die Empfindung noch einmal nachzuspüren. e) Wie fühlt es sich an, wenn Sie jetzt einen Löffel voller versalzener Suppe, Götterspeise, Knäckebrot usw. zu essen. Spüren Sie jetzt dieses Gefühl? Natürlich nur in Ihnen.', 'C', NULL, NULL, '2020-02-03 17:41:56', 1),
(4, 2, 'Peter Hans', 'Kalibrieren', 'Kalibrieren verlangt die Fähigkeit, nonverbale Signale genau wahrzunehmen und die Physiologie innerer Zustände äußeren Anzeichen zuzuordnen.', '1) Für die Übung Personenraten werden 2 Personen benötigt. Person A und B. 2) Person A bittet Person B, Denke an eine Person die Du magst. Beobachte den Gesichtsausdruck von Person B. Danach bittet Person A Person B, Denke an eine Person die Du nicht magst. Beobachte wieder den Gesichtsausdruck von Person B. Hier sollte es eine Veränderung im Gesichtsausdruck von Person B geben. Merke Dir diesen Gesichtsausdruck. 3) Nach dem ersten Schritt fragt Person A Person B = Welche Person ist Größer? Die die Du magst, oder nicht magst? Person B soll nur an die Person denken. 4) In dem Moment in dem Person B an die Person denkt, sollte Person A an der Mimik erkennen an welche Person gedacht wird. So kann anhand von kleinsten Signalen geübt werden, ganz viel in einer anderen Person zu erkennen.', 'E', NULL, 'https://www.youtube.com/watch?v=1UPv1nurmZ4', '2020-02-04 17:53:09', 1),
(5, 2, 'Peter Hans', 'Rapport Pacing und Leading', 'Die Voraussetzung für jede gute Kommunikation ist Vertrauen. Die meisten Menschen haben wenige gute Strategien, um zu anderen Menschen Sympathie herzustellen.', '1) Pacing Person A nimmt eine ähnliche oder gleiche Körperhaltung wie Person B ein. Unbewusst nimmt Person B auf Hey, der ist wie ich. Der Bewegt sich wie ich. Was kann alles gespiegelt werden, im Bereich der Körpersprache? Mimik, Gestik, Geschwindigkeit der Sprache, Körperhaltung, Sitzposition, Beinposition, Standhaltung, Detaillierte Sprache. Nach einer Zeit entwickelt sich ein Band der Sympathie zwischen Person A und B. Das kannst Du testen, indem Du in die Führung gehst, das Leading. 2) Leading Person A überprüft ob Person B ihr folgt. Person A verändert seine Körperhaltung. Nun überprüft Person A ob Person B ebenfalls die Körperhaltung verändert. Falls Person B die Körperhaltung auch verändert, dann hat das Führen funktioniert. Zwischen Person A und Person B herrscht nun ein starker Rapport. Falls das Führen nicht geklappt hat, muss Person A wieder mit dem Leading beginnen.', 'C', NULL, 'https://www.youtube.com/watch?v=jiQeWOUZE0s', '2020-02-05 18:07:11', 1),
(6, 4, 'Benedikt Wolf', 'Überkreuz Spiegeln', 'Überkreuz Spiegeln', 'Beim Spiegeln beispielsweise überkreuzt Person B die Beine und Person A macht das nach. Sodass Person A in der gleichen Körperhaltung wie Person B ist. Es gibt Situationen in denen das unpraktisch ist, exakt das gleiche zu tun wie Person B. Wie beispielsweise wenn Person B etwas erzählt und Person A der Zuhörer ist. Während Person B spricht, kann Person A den Rhythmus und die Körperdynamik von Person B einfangen und die Gestik in Kopfbewegungen spiegeln. Bei viel Gestik viel Kopfbewegung.', 'D', NULL, 'https://www.youtube.com/watch?v=BtDzx90iCLA', '2020-02-06 18:14:57', 0),
(7, 5, 'Benedikt Wolf', 'Klassisches Anker verschmelzen', 'Mittels dieser NLP-Technik können unangenehme Anker wirkungsvoll neutralisiert werden. Gebraucht wird ein starker positiver Anker, der gleichzeitig mit dem negativen Anker abgefeuert wird.', '1) Negativer. Anker Führe Deinen Partner in einen Zustand, in dem er Empfindungen hat, die er als unangemessen und unangenehm empfindet. Wenn er ganz drin ist, ankere diesen Zustand durch Berühren des Knies bzw. durch Berühren eines Fingerknöchels oder einer anderen unverfänglichen Körperseite. 2) Separator. Separiere Deinen Klienten, indem Du ihm Fragen stellst, die ihn in einen anderen, neutralen Zustand führen. Z. B. frage ihn, wo er zum letzten Mal im Urlaub war. 3) Testen. Teste durch erneutes Auslösen des Ankers, ob er wirkt. Wenn nicht, gehe zurück zu 1., wenn ja, dann weiter zu 2. 4) Positiver Anker. Führe Deinen Klienten in einen Zustand, in dem er die Empfindung hatte, die er in der ersten Situation gerne hätte. Ankere diesen Zustand auf dem anderen Knie bzw. auf dem gegenüberliegenden Knöchel. 5) Separator. Separiere Deinen Klienten wieder so wie in 2., aber vielleicht besser mit anderen Fragen. 6) Testen. Teste den positiven Anker, indem Du die entsprechende Stelle wieder berührst. Kalibriere Dich auf die Veränderungen, die Dein Klient nicht willkürlich hervorbringen kann. Versichere Dich durch Nachfragen, ob der Anker stark genug wirkt. Wenn Dein Klient durch Vorstellungen nachhelfen muss, damit der Anker wieder richtig wirkt, ist er noch nicht richtig installiert. Gehe dann nochmals zurück zu 4., andernfalls zu 7. 7) Verschmelzen der Anker. Halte jetzt den positiven Anker, und löse dann den negativen aus. Benutze den Hypnotalk auf der nächsten Seite. Warte bis sich die physiologischen Veränderungen beruhigt haben und Dein Klient einen symmetrischen, positiven Eindruck macht. Sollte der positive Anker nicht stark genug gewesen sein bzw. sollte diese Ressource nicht ausgereicht haben, gehe zurück zu 4. und ankere noch eine zusätzliche Ressource. 8) Test. Teste die Integration, indem Du Deinen Klienten bittest, an die unangenehme Situation zu denken, und achte darauf, wie er reagiert. Wenn die Physiologie noch Zeichen der Problemphysiologie enthält, dann zurück zu 4., wenn nicht, führe Deinen Klienten in zukünftige ähnliche Situationen (Future Pace).', 'B', NULL, 'https://www.youtube.com/watch?v=t2EMrb_WJUI', '2020-02-07 18:53:54', 1),
(8, 5, 'Benedikt Wolf', 'Die Swish-Technik', 'Die Swish-Technik hilft dabei lästige Gewohnheiten zu abzulegen und starke positive Motivation aufzubauen.', '1) Thema und Kontext: Finde ein unerwünschtes Verhalten oder eine unerwünschte Reaktion. 2) Auslösendes Bild: Assoziiert. Was geht dem unerwünschten Verhalten direkt voraus? Dabei sollte ein etwas unangenehmes Gefühl dabei sein. 3) Schaffung eines Zielbildes: Dissoziiert. Woran kann jemand von außen erkennen, dass Du eine Person bist für die ... kein Problem ist, dass Du die Eigenschaften und Ressourcen hast, um in gewünschter Weise zu reagieren. Große Anziehungskraft soll von dem Bild ausgehen. 4) Swish: Mach nun mit beiden Bildern den Swish. Beginne, indem Du das auslösende Bild des Kontextes groß und hell siehst. Setze dann ein kleines dunkles Bild der Zielvorstellung in die untere rechte Ecke. Das kleine dunkle Bild wird größer werden und das erste Bild ganz bedecken, welches gleichzeitig ebenso schnell verblassen und schrumpfen wird, wie Du Swish sagen kannst. 5) Wiederholung des Swish mindestens 7x. 8) Test: Stell Dir nun das erste Bild vor, was passiert? Das wird schwierig sein, wenn der Swish funktioniert hat. Eine andere Testmöglichkeit besteht darin, das Verhalten real zu testen.', 'F', NULL, 'https://www.youtube.com/watch?v=fk3HgeFyCmo', '2020-02-08 19:02:36', 1),
(9, 5, 'Benedikt Wolf', 'Walt-Disney-Strategie', 'Drei verschiedene Phasen der Zielsetzung und diese unterscheiden sowohl räumlich als auch zeitlich präzise von einander. Der kreativer Träumer, der re', '1) Markiere drei verschiedene Stellen im Raum. Achte darauf, dass jeder Raum dem Typ, der in ihm nachdenken, visualisieren, arbeiten soll, entspricht. 2) Durchlaufe in den nächsten Schritten die einzelnen Positionen relativ schnell, um einen ersten Eindruck von dieser Strategie zu gewinnen. 3) Nimm die Position des Träumers ein. 4) Erinnere Dich an eine Situation, in der Du kreativ und phantasievoll warst. Versetze Dich in diese Stimmung. Wenn Dir das schwer fällt, dann denke an eine Person, die oft kreativ ist und überlege Dir, wie diese Person das wohl macht. Wichtig ist, dass Du tatsächlich einen Zustand erreichst, in dem es Dir leicht fällt, zu träumen und kreative Ideen zu entwickeln. 5) Verlasse die Position des Träumers und schalte einen kurzen Moment auf Durchzug. Setze einen Separator. 6) Nimm nun die Position des realistischen Planers ein. Erinnere Dich an eine Zeit, in der es Dir leicht möglich war, realistisch und sorgfältig zu planen oder denke an jemanden, der dies sehr gut kann Suche Dir eine der Ideen Deines Träumers aus, die Du jetzt planen möchtest. Denke etwas über die Idee nach. Wie könntest Du diese Idee verwirklichen? Welche Schritte sind notwendig? In welcher Reihenfolge müssen sie getan werden? Wie lange wird es dauern, bis das Ziel erreicht ist? Welche Zwischenziele wären denkbar? 7) Verlasse die Position des Planers und setze wieder einen Separator. 8) Nimm die Position des konstruktiven Kritikers ein. Erinnere Dich an eine Zeit oder eine Situation, in der Du konstruktiv und kritisch warst, in der Du Hindernisse und Einwände frühzeitig erkannt hast und genau wusstest, wo Stärken und Schwächen eines Planes liegen. Oder denke an eine Person, die über diese Fähigkeit verfügt. Wo fühlst Du, dass Du jetzt Zugang zu diesem Gefühl hast? Versetze Dich in diese Stimmung. Schaue Dir das Ergebnis des Träumers und des Planers an. Spüre einmal hinein und entwickle ein Gefühl für den Plan. Wo fehlt noch etwas? Was wurde noch nicht berücksichtigt? Kannst Du mit diesem Plan Dein Ziel erreichen?', 'B', NULL, 'https://www.youtube.com/watch?v=EmdlS6usQjs&amp;featuhttps://www.youtube.com/watch?v=EmdlS6usQjs&amp;feature=emb_titlere=emb_title', '2020-02-09 19:14:01', 1),
(10, 5, 'Benedikt Wolf', 'Six-Step-Reframing', 'Das Six-Step-Reframing ist eines der berühmtesten NLP-Interventionsmodelle. In sechs Schritten können Verhaltensgewohnheiten beleuchtet und verändert werden.', '1) zu veränderndes Muster (X) identifizieren. Identifiziere das Muster (X), das verändert werden soll: Ich möchte mit X aufhören, aber ich kann nicht. Ich möchte Y machen, aber etwas hält mich zurück. 2) Aufbau der Kommunikation mit dem verantwortlichen Teil. Etabliere die Kommunikation zu dem Teil, der für das Muster verantwortlich ist. Wird der Teil von mir, der mich zu X veranlasst, im Bewusstsein mit mir kommunizieren? Achte auf alles - Gefühle oder Bilder, Gerüche oderTöne -, was als Antwort auf diese Frage internal passiert. Etabliere die ja oder nein-Bedeutung des Signals. Lasse Klarheit, Lautstärke oder Intensität für Ja zunehmen und für Nein abnehmen. 3) Trennung von Verhalten und positiver Absicht. Trenne das Verhalten, das Muster X, von der positiven Absicht desjenigen Teils, der für X verantwortlich ist. Das unerwünschte Verhalten ist nur ein Weg, eine bestimmte positive Funktion zu erreichen. Frage den für X zuständigen Teil: Wärst du bereit, mich im Bewusstsein wissen zu lassen, was du mit dem Muster X für mich zu tun versuchst? Bekommst Du eine Ja-Antwort, bitte den Teil seine Absicht mitzuteilen. Bekommst Du eine Nein-Antwort, mache mit dem unbewussten Reframing weiter, mit der Präsupposition einer positiven Absicht. Ist diese Absicht für das Bewusstsein akzeptabel? Möchtest Du einen Teil haben, der diese Funktion ausübt? Frage den für X zuständigen Teil: Falls es Möglichkeiten gäbe, Deine positive Funktion genauso gut oder besser auszuüben als mit Hilfe von X, hättest Du Interesse daran, sie auszuprobieren? 4) Mithilfe des kreativen Teils neue Verhaltensweisen entwickeln. Finde Zugang zu einem kreativen Teil und bringe neue Verhaltensweisen hervor, um die positive Funktion auszuüben. Mache Dir Erfahrungen von Kreativität zugänglich und ankere diese oder frage: Bin Ich mir dessen bewusst, einen kreativen Teil zu haben? Lasse den Teil, der für X zuständig ist, dem kreativen Teil seine positive Funktion mitteilen, erlaube dem kreativen Teil, weitere Möglichkeiten für die Ausübung dieser Funktion hervorzubringen und lasse den Teil, der für X zuständig war, unter diesen Möglichkeiten drei aussuchen, die mindestens so gut sind wie X oder besser. Lasse ihn jedes Mal ein Ja-Signal schicken, wenn er eine solche Alternative auswählt. 5) Übernahme der Verantwortung und Überbrückung in die Zukunft sicherstellen. Frage den Teil: Bist Du bereit, die Verantwortung dafür zu übernehmen, die drei neuen Alternativen im entsprechenden Kontext zu benutzen? Dadurch ist auch für eine Überbrückung in die Zukunft gesorgt. Zusätzlich kannst Du auf der unbewussten Ebene den Teil bitten, die sensorischen Hinweise zu identifizieren, die die neuen Wahlmöglichkeiten auslösen, um vollständig die Erfahrung zu machen, wie es ist, wenn diese sensorischen Hinweise mühelos und automatisch jeweils eine der neuen Wahlmöglichkeiten herbeiführen. 6) Ökologischer Check. Hat irgendeiner meiner Teile etwas gegen die drei neuen Alternativen einzuwenden? Bei einer Ja-Reaktion gehe zurück nach oben zu Schritt 2.', 'E', NULL, 'https://www.youtube.com/watch?v=l3feaKfUU7A&amp;feature=emb_title', '2020-02-10 19:24:57', 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `token`
--
-- Erstellt am: 14. Feb 2020 um 15:29
-- Zuletzt aktualisiert: 14. Feb 2020 um 19:34
--

DROP TABLE IF EXISTS `token`;
CREATE TABLE `token` (
  `id` int(11) NOT NULL,
  `tokenstring` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires` datetime NOT NULL,
  `userid` int(11) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `userdata`
--
-- Erstellt am: 14. Feb 2020 um 15:30
-- Zuletzt aktualisiert: 14. Feb 2020 um 19:35
--

DROP TABLE IF EXISTS `userdata`;
CREATE TABLE `userdata` (
  `id` int(11) NOT NULL,
  `firstname` varchar(75) NOT NULL,
  `lastname` varchar(75) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL,
  `birthday` date DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `userdata`
--

INSERT INTO `userdata` (`id`, `firstname`, `lastname`, `email`, `password`, `birthday`, `country`) VALUES
(1, 'Benedikt', 'Wolf', 'b-wolf@posteo.de', '$2y$10$nIxBB616Z.kiKISZhvuugek/UpSrHynn4EkIGXVhC9wo8QyJCYEEC', '1993-08-09', 'Deutschland'),
(2, 'Peter', 'Hans', 'peter-hans123@web.de', '$2y$10$pQ.XLKmEDOwR8vWUs3OWceosgtATnVAyPN045BJKzvL7/7/ecpory', '1970-01-01', 'Belgien'),
(3, 'Sabrina', 'Walter', 'sabrina-walter123@gmail.com', '$2y$10$6.hrXGGRkM.aTVmthazwIOhUmGujvIwXcZXQdHSChBlLBzHdpr96G', '2000-08-01', 'Montenegro'),
(4, 'Franz', 'Hollister', 'franz-hollister123@web.de', '$2y$10$kGhJZTD8d8HZs40ot4evN.p9UAGu.S6ZnJBuOuqbKL1T379D0aTKG', '1970-01-01', ''),
(5, 'Miguel', 'Koch', 'miguel-koch123@gmai.com', '$2y$10$.gPJxfbt3RqVAHUST9am3.oDodYF9J1.UaVLs7ysWY8g2L13V2ily', '1980-07-09', 'Albanien'),
(6, 'Patrick', 'Mulch', 'patrick-mulch123@gmail.com', '$2y$10$xT8EuyKi/tXEJjI7e2BiTeGFA7ZW.I5t9exW6CeI7NnNwlgfh3EcO', NULL, NULL),
(7, 'Kim Sina', 'Meyer', 'kim-meyeer123@web.de', '$2y$10$9dZJDG1kEKF0/XUkMqf7He3yLIEJJ31JqwX3w47tGROhSl3GW9TV2', '2002-10-09', NULL),
(8, 'Ricarda', 'Baumgartner', 'ricarda-baumgartner123@web.de', '$2y$10$B5BFKyiSeO6C9hiM82wlC.D.1og81M7KcYf9OZq3UFywOVLeUg9JC', NULL, NULL),
(10, 'Sdjkfb', 'Jkasbdkjsab', 'asjkdbs@gmail.com', '$2y$10$Pl2wzgIF3i.zYOogXVqy6.7201DtylafNRY990PZ1m1FX8u73R4jy', NULL, NULL),
(11, 'Asd', 'Asd', 'asd123@web.de', '$2y$10$Vt3mqKzsW.TSJn0VVO6K4enIWVcwcQkvfv14ZUWhNPJex9YddqbEi', NULL, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `userinfo`
--
-- Erstellt am: 13. Feb 2020 um 11:43
-- Zuletzt aktualisiert: 14. Feb 2020 um 19:35
--

DROP TABLE IF EXISTS `userinfo`;
CREATE TABLE `userinfo` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `registered` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastlogin` datetime DEFAULT NULL,
  `ipaddress` varchar(20) NOT NULL,
  `rights` int(2) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `userinfo`
--

INSERT INTO `userinfo` (`id`, `userid`, `registered`, `lastlogin`, `ipaddress`, `rights`, `status`, `active`) VALUES
(1, 1, '2020-02-01 16:44:22', '2020-02-14 16:45:21', '::1', 99, 0, 1),
(2, 2, '2020-02-02 17:53:58', '2020-02-14 19:29:44', '::1', 60, 0, 1),
(3, 3, '2020-02-03 18:01:16', '2020-02-14 19:28:21', '::1', 50, 0, 1),
(4, 4, '2020-02-04 18:21:04', '2020-02-14 19:34:40', '::1', 30, 0, 1),
(5, 5, '2020-02-05 18:28:33', '2020-02-14 19:33:22', '::1', 20, 0, 1),
(6, 6, '2020-02-06 18:30:33', '2020-02-14 20:35:43', '::1', 10, 0, 1),
(7, 7, '2020-02-07 18:34:38', NULL, '::1', 0, 0, 1),
(8, 8, '2020-02-14 18:37:27', NULL, '::1', 0, 1, 1),
(10, 10, '2020-02-14 18:44:05', NULL, '::1', 0, 0, 1),
(11, 11, '2020-02-14 18:44:28', NULL, '::1', 0, 0, 0);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `src` (`src`),
  ADD UNIQUE KEY `nlpid` (`nlpid`);

--
-- Indizes für die Tabelle `nlp`
--
ALTER TABLE `nlp`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `soundcloud` (`soundcloud`,`youtube`);

--
-- Indizes für die Tabelle `token`
--
ALTER TABLE `token`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tokenstring` (`tokenstring`);

--
-- Indizes für die Tabelle `userdata`
--
ALTER TABLE `userdata`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indizes für die Tabelle `userinfo`
--
ALTER TABLE `userinfo`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `userid` (`userid`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT für Tabelle `nlp`
--
ALTER TABLE `nlp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT für Tabelle `token`
--
ALTER TABLE `token`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `userdata`
--
ALTER TABLE `userdata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT für Tabelle `userinfo`
--
ALTER TABLE `userinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
